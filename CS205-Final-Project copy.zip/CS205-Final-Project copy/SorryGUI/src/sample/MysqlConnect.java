package sample;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import java.util.Date;
import java.util.Calendar;
import java.sql.Timestamp;

import java.util.ResourceBundle;



public class MysqlConnect {


    public MysqlConnect(String theName, boolean theValue, String theWinner, int theMoves) {
        //Variables
        String name = theName;
        boolean value = theValue;
        String winner = theWinner;
        int moves = theMoves;


        //public static void main(String[] args) {
        // System.out.println("MySQL Connect Example.");
        Connection conn = null;
        Statement stmt = null;

        java.util.Date thedate = new java.util.Date();
        Timestamp date = new Timestamp(thedate.getTime());


        //ResourceBundle properties = ResourceBundle.getBundle("MysqlConnect");
        String url = "jdbc:mysql://webdb.uvm.edu/";
        String dbName = "GGIRDZIS_CS205";
        String driver = "com.mysql.jdbc.Driver";
        String userName = "ggirdzis_admin";
        String password = "NB1FSgATnsmK";


        try {
            Class.forName(driver).newInstance();
            conn = DriverManager.getConnection(url + dbName, userName, password);


            stmt = conn.createStatement();

            String sql = "INSERT INTO tblPlayer " +
                    "VALUES ('" + name + "'," + value + ", '" + winner + "', " + moves + ", '" + date + "')";
            stmt.executeUpdate(sql);

            String sql2 = "SELECT fldName,fldSetting,fldResult,fldMoves FROM tblPlayer";
            ResultSet rs = stmt.executeQuery(sql2);
            
            String data="";
            data+=("Player Name\t");
            data+=("Setting\t\t");
            data+=("Winner\t\t");
            data+=("Moves\t");

            while (rs.next()) {

                data+=("\n\n");
                String username = rs.getString("fldName");
                String setting = rs.getString("fldSetting");
                String result = rs.getString("fldResult");
                String move = rs.getString("fldMoves");



                data+=(username+"\t\t");
                data+=(setting+"\t\t");
                data+=(result+"\t\t");
                data+=(move+"\t\t");
            }

            //stmt.executeUpdate(sql);
            newWindow(data);
        } catch (Exception e) {
            System.err.println("Error MysqlConnect.myConnect: " + e.getMessage());
            e.printStackTrace();
        }


        //}
    }
    public void newWindow(String data){
        ScrollPane root = new ScrollPane();
        Stage stage = new Stage();
        stage.setTitle("Statistics");
        stage.setScene(new Scene(root, 500,500));
        stage.show();
        Label l = new Label(data);
        root.setContent(l);
    }
}

            

 
   
   
   
   



